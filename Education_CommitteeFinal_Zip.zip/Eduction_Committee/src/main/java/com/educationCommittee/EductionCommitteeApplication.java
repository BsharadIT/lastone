package com.educationCommittee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EductionCommitteeApplication {

	public static void main(String[] args) {
		SpringApplication.run(EductionCommitteeApplication.class, args);
	}

}
